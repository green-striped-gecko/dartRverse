BayeScan 2.1 (Foll and Gaggiotti 2008), https://cmpg.unibe.ch/software/BayeScan/
Distributed under the GNU General Public License v3 (see COPYING). The source
code is in BayeScan2.1.zip at the URL above (folder source/).

This binary was built from the BayeScan 2.1 source on GitHub Actions
(windows-latest, MSYS2 MINGW64, g++.exe (Rev4, Built by MSYS2 project) 16.2.0), 64-bit, linked
statically so that no MinGW DLLs are needed:
  g++ -std=gnu++14 -O3 -fopenmp -static -include prelude.h -o bayescan.exe
    start.cpp beta.cpp dirichlet.cpp RJupdates.cpp MHupdates.cpp
    likelihood.cpp read_write.cpp anyoption.cpp
prelude.h includes the system headers BayeScan uses and then
#define fstat bayescan_fstat, because the MinGW headers declare a
function fstat() that clashes with BayeScan's variable of that name.

Modification (2026-10-14): the function read_discarded() in
read_write.cpp had no return statement; "return 0;" was added at its
end. Without it, GCC 8 and later compile the loop that reads the file
given with option -d into an endless loop, and bayescan -d never
finishes. Nothing else in the source was changed.
