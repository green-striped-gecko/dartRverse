BayeScan 2.1 (Foll and Gaggiotti 2008), https://cmpg.unibe.ch/software/BayeScan/
Distributed under the GNU General Public License v3 (see COPYING). The source
code is in BayeScan2.1.zip at the URL above (folder source/).

This is BayeScan2.1_linux64bits from the official distribution (x86-64,
statically linked), renamed to bayescan.
