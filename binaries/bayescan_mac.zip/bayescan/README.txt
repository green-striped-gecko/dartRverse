BayeScan 2.1 (Foll and Gaggiotti 2008), https://cmpg.unibe.ch/software/BayeScan/
Distributed under the GNU General Public License v3 (see COPYING). The source
code is in BayeScan2.1.zip at the URL above (folder source/).

This binary was built from the unmodified BayeScan 2.1 source as a universal
binary (arm64 and x86_64, macOS 11 or later). LLVM OpenMP 22.1.8 is linked
statically, so no Homebrew or GCC libraries are needed:
  clang++ -arch <arch> -O3 -mmacosx-version-min=11.0 -Xpreprocessor -fopenmp \
    start.cpp beta.cpp dirichlet.cpp RJupdates.cpp MHupdates.cpp \
    likelihood.cpp read_write.cpp anyoption.cpp libomp.a -o bayescan
  lipo -create bayescan_arm64 bayescan_x86_64 -output bayescan
